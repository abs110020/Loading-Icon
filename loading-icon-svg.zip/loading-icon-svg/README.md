# Loading Icon svg

A Pen created on CodePen.io. Original URL: [https://codepen.io/abs110020/pen/JXNYdM](https://codepen.io/abs110020/pen/JXNYdM).

